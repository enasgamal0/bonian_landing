import locale6010b66b from '../..\\locales\\en-US.js'

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {"locale":"en","fallbackLocale":"en"},
  vueI18nLoader: false,
  locales: [{"name":"عربي ","code":"ar","iso":"ar-AR","file":"ar-AR.js","dir":"rtl"},{"name":"English","code":"en","iso":"en-US","file":"en-US.js","dir":"ltr"}],
  defaultLocale: "ar",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "prefix_except_default",
  lazy: true,
  langDir: "D:\\Enas\\Bonian_landing\\locales",
  rootRedirect: null,
  detectBrowserLanguage: false,
  differentDomains: false,
  seo: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncLocale":false,"syncMessages":false,"syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  beforeLanguageSwitch: () => null,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"name":"عربي ","code":"ar","iso":"ar-AR","file":"ar-AR.js","dir":"rtl"},{"name":"English","code":"en","iso":"en-US","file":"en-US.js","dir":"ltr"}],
  localeCodes: ["ar","en"],
}

export const localeMessages = {
  'en-US.js': () => Promise.resolve(locale6010b66b),
  'ar-AR.js': () => import('../..\\locales\\ar-AR.js' /* webpackChunkName: "lang-ar-AR.js" */),
}
