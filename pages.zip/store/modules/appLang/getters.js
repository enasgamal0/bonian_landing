export default {
    // START:: GET APP LOCALE
    appLocale(state) {
        return state.starter_app_lang;
    },
    // END:: GET APP LOCALE
};
