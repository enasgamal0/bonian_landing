export default {
    // START:: SET APP LOCALE
    setAppLocale(state, payload) {
        state.starter_app_lang = payload;
    },
    // END:: SET APP LOCALE
};
