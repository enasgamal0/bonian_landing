export default {
  postsData(state) {
    return state.posts;
  },
};
